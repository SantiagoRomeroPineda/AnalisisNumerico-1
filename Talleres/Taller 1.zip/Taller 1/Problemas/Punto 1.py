a=536.78
b=536.8

Err=abs(a-b)
Err=Err/a
Err=Err*100
print(" El error es: "+str(Err)+"%")
